package datamodel;


public class Wine {

         String wine;
     boolean isPairingAvailable;

    public String getWine() {return wine;}
    public void setWine(String wine) {this.wine = wine;}

    public boolean isPairingAvailable() {return isPairingAvailable;}
    public void setPairingAvailable(boolean pairingAvailable) {isPairingAvailable = pairingAvailable;}
}

